# Python OOP Banking System

A beginner-friendly, menu-driven Python project demonstrating Object-Oriented Programming (OOP) through a simple educational banking application.

> **Important:** This is a learning/demo project. It stores data in memory, uses no authentication, and is not suitable for real banking or sensitive financial information.

## Features

- Create savings and current accounts
- Deposit money and withdraw with insufficient-funds checks
- Check account balances
- View all accounts
- View transaction history with timestamps and balance after each transaction
- Validate user inputs and handle errors
- Demonstrate classes, objects, constructors, methods, encapsulation, inheritance, polymorphism, and abstraction

## OOP Design

- `Transaction`: records the time, type, amount, and resulting balance.
- `BankAccount`: abstract base class for shared account behavior.
- `SavingsAccount`: concrete account type.
- `CurrentAccount`: another concrete account type.
- `Bank`: creates, stores, and finds accounts.

## Class Diagram

```mermaid
classDiagram
    class Bank {
        -dict _accounts
        +create_account(type, number, holder, opening_balance)
        +get_account(number)
        +list_accounts()
    }

    class BankAccount {
        <<abstract>>
        -float __balance
        +get_balance()
        +deposit(amount)
        +withdraw(amount)
        +transaction_history()
        +account_type()* str
    }

    class SavingsAccount {
        +account_type() str
    }

    class CurrentAccount {
        +account_type() str
    }

    class Transaction {
        +timestamp
        +transaction_type
        +amount
        +balance_after
    }

    Bank o-- BankAccount : manages
    BankAccount <|-- SavingsAccount
    BankAccount <|-- CurrentAccount
    BankAccount o-- Transaction : history
```

## Run the project

Requires Python 3.9 or newer. No third-party packages are required.

```bash
python banking_system.py
```

Follow the interactive menu to create accounts, deposit, withdraw, check balances, and view transaction history.

## Example workflow

```text
Welcome to Learning Bank — OOP Banking System
1. Create account
2. List accounts
3. Check balance
4. Deposit
5. Withdraw
6. Transaction history
0. Exit

Choose an option: 1
Account type (savings/current): savings
Account number: A101
Account holder name: Kamal
Opening balance (0 or more): 1000
Account created: Savings | Account: A101 | Holder: Kamal | Balance: 1000.00
```

## Concepts demonstrated

| OOP / Python concept | Example |
|---|---|
| Class and object | `BankAccount`, `SavingsAccount`, `Bank` |
| Constructor | `__init__()` |
| Methods | `deposit()`, `withdraw()`, `get_balance()` |
| Encapsulation | Private `__balance` with controlled methods |
| Inheritance | Savings/current accounts extend `BankAccount` |
| Polymorphism | Each account implements `account_type()` |
| Abstraction | Abstract `BankAccount` and `account_type()` |
| Exception handling | `try` / `except` and input validation |
| Clean design | Separate transaction, account, and bank responsibilities |

## Limitations and possible improvements

- Accounts are stored in memory and disappear when the program exits.
- No authentication or user authorization is implemented.
- This project uses floating-point numbers for simplicity; real financial applications should use `decimal.Decimal`.
- Production systems require persistent storage, security controls, audit logging, concurrency handling, and extensive tests.

Possible next steps: add SQLite persistence, automated unit tests, a GUI or web interface, and role-based access controls.

## Author

**Kamal Dhaka**  
B.Tech — Artificial Intelligence & Data Science

Built for learning Python OOP and software design fundamentals.
