"""Educational OOP Banking System.

This is a local learning project, not production banking software.
It stores account data in memory; data resets when the program exits.
"""

from abc import ABC, abstractmethod
from datetime import datetime


class Transaction:
    """One transaction entry."""

    def __init__(self, transaction_type, amount, balance_after):
        self.timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.transaction_type = transaction_type
        self.amount = amount
        self.balance_after = balance_after

    def __str__(self):
        return (
            f"{self.timestamp} | {self.transaction_type:<10} | "
            f"Amount: {self.amount:.2f} | Balance: {self.balance_after:.2f}"
        )


class BankAccount(ABC):
    """Abstract base class representing a bank account."""

    def __init__(self, account_number, holder_name, opening_balance=0.0):
        if not account_number.strip():
            raise ValueError("Account number cannot be empty.")
        if not holder_name.strip():
            raise ValueError("Account holder name cannot be empty.")
        if opening_balance < 0:
            raise ValueError("Opening balance cannot be negative.")

        self.account_number = account_number.strip()
        self.holder_name = holder_name.strip()
        self.__balance = float(opening_balance)  # Encapsulation
        self._transactions = []
        if opening_balance > 0:
            self._record("OPENING DEPOSIT", float(opening_balance))

    def get_balance(self):
        """Return current balance without exposing the private field."""
        return self.__balance

    def _record(self, transaction_type, amount):
        self._transactions.append(
            Transaction(transaction_type, amount, self.__balance)
        )

    def deposit(self, amount):
        if amount <= 0:
            raise ValueError("Deposit amount must be greater than zero.")
        self.__balance += float(amount)
        self._record("DEPOSIT", float(amount))
        return self.__balance

    def withdraw(self, amount):
        if amount <= 0:
            raise ValueError("Withdrawal amount must be greater than zero.")
        if amount > self.__balance:
            raise ValueError("Insufficient funds.")
        self.__balance -= float(amount)
        self._record("WITHDRAWAL", float(amount))
        return self.__balance

    def transaction_history(self):
        return list(self._transactions)

    @abstractmethod
    def account_type(self):
        """Return the concrete account type."""
        raise NotImplementedError

    def __str__(self):
        return (
            f"{self.account_type()} | Account: {self.account_number} | "
            f"Holder: {self.holder_name} | Balance: {self.get_balance():.2f}"
        )


class SavingsAccount(BankAccount):
    """Savings account; demonstrates inheritance and method implementation."""

    def account_type(self):
        return "Savings"


class CurrentAccount(BankAccount):
    """Current account; demonstrates polymorphism."""

    def account_type(self):
        return "Current"


class Bank:
    """Coordinates account creation, lookup, and bank operations."""

    def __init__(self, name):
        self.name = name
        self._accounts = {}

    def create_account(self, account_type, account_number, holder_name, opening_balance=0.0):
        account_number = account_number.strip()
        if account_number in self._accounts:
            raise ValueError("That account number already exists.")

        account_type = account_type.strip().lower()
        classes = {
            "savings": SavingsAccount,
            "current": CurrentAccount,
        }
        if account_type not in classes:
            raise ValueError("Account type must be 'savings' or 'current'.")

        account = classes[account_type](account_number, holder_name, opening_balance)
        self._accounts[account_number] = account
        return account

    def get_account(self, account_number):
        account_number = account_number.strip()
        if account_number not in self._accounts:
            raise ValueError("Account not found.")
        return self._accounts[account_number]

    def list_accounts(self):
        return list(self._accounts.values())


def read_amount(prompt):
    """Read and validate a positive numeric amount."""
    try:
        amount = float(input(prompt))
    except ValueError as exc:
        raise ValueError("Please enter a valid numeric amount.") from exc
    if amount <= 0:
        raise ValueError("Amount must be greater than zero.")
    return amount


def main():
    bank = Bank("Learning Bank")
    print(f"Welcome to {bank.name} — OOP Banking System")

    while True:
        print(
            "\n1. Create account\n2. List accounts\n3. Check balance\n"
            "4. Deposit\n5. Withdraw\n6. Transaction history\n0. Exit"
        )
        choice = input("Choose an option: ").strip()

        try:
            if choice == "1":
                kind = input("Account type (savings/current): ")
                number = input("Account number: ")
                holder = input("Account holder name: ")
                opening = float(input("Opening balance (0 or more): "))
                account = bank.create_account(kind, number, holder, opening)
                print("Account created:", account)

            elif choice == "2":
                accounts = bank.list_accounts()
                if not accounts:
                    print("No accounts have been created.")
                for account in accounts:
                    print(account)

            elif choice == "3":
                account = bank.get_account(input("Account number: "))
                print(f"Available balance: {account.get_balance():.2f}")

            elif choice == "4":
                account = bank.get_account(input("Account number: "))
                balance = account.deposit(read_amount("Deposit amount: "))
                print(f"Deposit successful. New balance: {balance:.2f}")

            elif choice == "5":
                account = bank.get_account(input("Account number: "))
                balance = account.withdraw(read_amount("Withdrawal amount: "))
                print(f"Withdrawal successful. New balance: {balance:.2f}")

            elif choice == "6":
                account = bank.get_account(input("Account number: "))
                history = account.transaction_history()
                if not history:
                    print("No transactions yet.")
                else:
                    for transaction in history:
                        print(transaction)

            elif choice == "0":
                print("Thank you for using the learning banking system.")
                break

            else:
                print("Invalid choice. Select an option from 0 to 6.")

        except (ValueError, KeyboardInterrupt) as error:
            if isinstance(error, KeyboardInterrupt):
                print("\nInput interrupted.")
            else:
                print("Error:", error)


if __name__ == "__main__":
    main()
